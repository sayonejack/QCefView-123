---
name: Feature request 【提议你想增加的功能】
about: Suggest an idea for this project 【请使用此模板发起新特性需求】
title: "[FEATURE]"
labels: triage
assignees: tishion

---

[//]: # (以下所有的以"[//]: #"开始的文字都是注释，不会被markdown渲染，所以无需删除)
[//]: # (All lines start "with [//]: #" below are comment lines and will not be rendered by markdown, so there's no need to delete them)

** Feature Description 【特性详细描述】**

[//]: # (请在下面描述所需新特性的详细信息)
[//]: # (Please describe the detailed information about the request feature)
...
