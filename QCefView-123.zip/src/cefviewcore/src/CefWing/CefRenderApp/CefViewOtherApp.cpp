﻿//
//  CefOtherApp.cpp
//  CefViewWing
//
//  Created by Sheen Tian on 2020/6/17.
//

#pragma region project_heasers
#include "CefViewOtherApp.h"
#pragma endregion project_heasers

CefViewOtherApp::CefViewOtherApp() {}
