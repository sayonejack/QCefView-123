﻿#include "QCefEventPrivate.h"

QCefEventPrivate::QCefEventPrivate() {}

QCefEventPrivate::~QCefEventPrivate() {}
